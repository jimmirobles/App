<?php $__env->startSection('modal-id', 'firmaModal'); ?>
<?php $__env->startSection('modal-title', 'Enviar comentarios...'); ?>

<?php $__env->startSection('modal-content'); ?>
<?php echo e(Form::open(['route' => 'comentarios.store', 'method' => 'POST'])); ?>

	<div class="modal-body">
		<input type="hidden" name="id_documento" value="<?php echo e($documento->id); ?>">
		<?php echo e(Form::textarea('comentario', null, ['class' => 'form-control', 'required'])); ?>

	</div>
	<div class="modal-footer">
		<button type="submit" class="btn btn-default">Guardar</button>
		<button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
	</div>
<?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>