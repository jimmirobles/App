<?php $__env->startSection('page-title', 'Crear documento'); ?>

<?php $__env->startSection('wrapper-title'); ?>
	<i class="fa fa-pencil"></i> Crear documento
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-12">

			<?php echo $__env->make('errors.form-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
			<?php echo Form::open(['route'=>'documentos.store', 'method'=>'POST', 'id' => 'myForm']); ?>

				<section class="row">
					<div class="col-lg-3 form-group">
						<?php echo Form::label('folio', 'Folio:'); ?>

						<?php echo Form::text('folio', $next_folio+1, ['class'=>'form-control', 'readonly']); ?>

					</div>
					<div class="col-lg-3 form-group">
						<?php echo Form::label('fecha', 'Fecha:'); ?>

						<?php echo Form::date('fecha', \Carbon\Carbon::now(), ['class'=>'form-control', 'required']); ?>

					</div>
					<div class="col-lg-3 form-group">
						<?php echo Form::label('hInicial', 'Hora inicial:'); ?>

						<?php echo Form::time('hInicial', null, ['class' => 'form-control timepicker', 'required']); ?>

					</div>
					<div class="col-lg-3 form-group">
						<?php echo Form::label('hFinal', 'Hora final:'); ?>

						<?php echo Form::time('hFinal', null, ['class' => 'form-control timepicker', 'required']); ?>

						
					</div>
				</section>
				<section class="row">
					<div class="col-lg-6 form-group">
						<?php echo Form::label('tipo', 'Tipo:'); ?>

						<?php echo Form::select('tipo', ['0' => 'Soporte', '1' => 'Iguala'], null, ['class'=>'form-control select2', 'placeholder'=>'Selecciona algo...', 'required']); ?>

					</div>
					<div class="col-lg-6 form-group">
						<?php echo Form::label('lugar', 'Lugar:'); ?>

						<?php echo Form::select('lugar', ['0' => 'En sitio', '1' => 'Remoto'], null, ['class'=>'form-control select2', 'placeholder'=>'Selecciona algo...', 'required']); ?>

					</div>
				</section>
				<section class="row">
					<div class="col-lg-6 form-group">
						<?php echo Form::label('id_cliente', 'Cliente:'); ?>

						<?php echo Form::select('id_cliente', $empresas->all(), null, ['class'=>'form-control select2', 'placeholder'=>'Selecciona algo...', 'required']); ?>

					</div>
					<div class="col-lg-6 form-group">
						<label>Contacto:</label>
						<select id="id_contacto" class="form-control select2" name="id_contacto">
							<option value=""></option>
						</select>
					</div>
				</section>
				<section class="row">
					<div class="col-lg-6 form-group">
						<?php echo Form::label('id_servicio', 'Servicio:'); ?>

						<?php echo Form::select('id_servicio', $servicios->all(), null, ['class'=>'form-control select2', 'placeholder'=>'Selecciona algo...', 'required']); ?>

					</div>
					<div class="col-lg-6 form-group">
						<?php echo Form::label('id_asesor', 'Asesor:'); ?>

						<?php echo Form::select('id_asesor', $asesores->all(), null, ['class'=>'form-control select2', 'placeholder'=>'Selecciona algo...', 'required']); ?>

					</div>
				</section>
				<section class="row">
					<div class="col-lg-12 form-group">
						<?php echo Form::label('error', 'Error reportado:'); ?>

						<?php echo Form::textarea('error', null, ['class' => 'form-control', 'rows' => '3']); ?>

					</div>
					<div class="col-lg-12 form-group">
						<?php echo Form::label('solucion', 'Actividad realizada:'); ?>

						<?php echo Form::textarea('solucion', null, ['class' => 'form-control', 'rows' => '3']); ?>

					</div>
					<div class="col-lg-12 form-group">
						<?php echo Form::label('comentarios', 'Comentrios adicionales:'); ?>

						<?php echo Form::textarea('comentarios', null, ['class' => 'form-control', 'rows' => '3']); ?>

					</div>
				</section>
				<div class="form-group">
					<?php echo Form::submit('Guardar', ['class'=>'btn btn-primary']); ?>

					<a class="btn btn-danger" href="<?php echo e(URL::previous()); ?>">Cancelar</a>
				</div>
			<?php echo Form::close(); ?>

		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_scripts'); ?>
<script>
	$(function () {
		$('.timepicker').timepicker({
		    timeFormat: 'HH:mm',
		    dropdown: false
		});
		$('.select2').select2({
			theme: "bootstrap"
		});
		$('#id_cliente').on('change', function(e){
			// console.log(e);
			var cliente_id = e.target.value;
			var contactos = $('#id_contacto');
			$.get('<?php echo e(url('documentos')); ?>/create/ajax-contacto?cliente=' + cliente_id, function(data) {
				// console.log(data);
				contactos.empty();
				$.each(data, function(value, display){
					contactos.append('<option value="' + display.id + '">' + display.nombre + '</option>');
				});
			});
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>