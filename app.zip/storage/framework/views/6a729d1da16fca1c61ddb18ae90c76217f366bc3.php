<?php $__env->startSection('page-title', 'Hosts'); ?>

<?php $__env->startSection('wrapper-title'); ?>
	<i class="fa fa-globe"></i> Listado de dominios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-buttons'); ?>
	<div class="pull-right">
		<div class="btn-group btn-group-sm" role="group" aria-label="Botones de acciones de tabla">
			<a role="button" href="<?php echo e(route('hosts.create')); ?>" class="btn btn-sm btn-outline-primary"><i class="fa fa-pencil fa-fw"></i> Nuevo</a>
			<div class="btn-group btn-group-sm" role="group">
			<button id="btnGroupDrop1" type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
			<div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
				<a class="dropdown-item" href="#">Descargar .XLS</a>
			</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="table-responsive">
		<table class="table table-bordered table-sm">
			<thead class="thead-light">
				<tr>
					<th>Cliente</th>
					<th>Dominio</th>
					<th>Fecha Inicial</th>
					<th>Fecha Final</th>
					<th>Tiempo restante</th>
					<th class="text-center"><i class="fa fa-cog fa-lg"></i></th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $hosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $host): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($host->cliente_nombre); ?></td>
						<td><?php echo e($host->dominio); ?></td>
						<td><?php echo e($host->fecha_inicial); ?></td>
						<td>
							<?php if(\Carbon\Carbon::parse($host->fecha_final)->isPast()): ?>
								<span class="badge badge-danger"><?php echo e($host->fecha_final); ?></span>
							<?php else: ?> 
								<span class="badge badge-success"><?php echo e($host->fecha_final); ?></span>
							<?php endif; ?>
						</td>
						<td><?php echo e(\Carbon\Carbon::parse($host->fecha_final)->diffForHumans()); ?></td>
						<td><a role="button" href="<?php echo e(route('hosts.destroy', $host->id)); ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Deseas eliminarlo?')" data-toggle="tooltip" data-placement="left" title="Borrar"><i class="fa fa-trash"></i></a></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>