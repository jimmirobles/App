<?php $__env->startSection('formulario'); ?>

      <?php echo Form::open(['route'=>'login', 'method'=>'POST', 'class' => 'form-signin']); ?>

        <h2 class="form-signin-heading">Iniciar sesión</h2>
          <?php echo Form::label('email', 'Email:', ['class' => 'sr-only']); ?>

          <?php echo Form::email('email', old('email'), ['class'=>'form-control', 'placeholder'=>'alguien@mail.com', 'required']); ?>

          <?php echo Form::label('password', 'Contraseña:', ['class' => 'sr-only']); ?>

          <?php echo Form::password('password', ['class'=>'form-control', 'placeholder'=>'******', 'required']); ?>

          <?php echo Form::submit('Entrar', ['class'=>'btn btn-lg btn-primary btn-block']); ?>

      <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>