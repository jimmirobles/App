<?php $__env->startSection('modal-id', 'sendEmailModal'); ?>

<?php $__env->startSection('modal-title', 'Envío de email...'); ?>

<?php $__env->startSection('modal-content'); ?>
	<?php echo e(Form::open(['route'=>'send', 'method'=>'POST'])); ?>

	<div class="modal-body">
		<div class="form-group">
			<label>Se enviara un correo a:</label>
			<input type="text" id="email" class="form-control" readonly>
		</div>
		<div class="checkbox">
			<label>
				<?php echo Form::checkbox('copyJefe', '1', null, ['id' => 'copyJefe']);; ?> CC. al supervisor
			</label>
		</div>
		<div class="checkbox">
			<label>
				<?php echo Form::checkbox('copyMe', '1', null, ['id' => 'copyMe']);; ?> CC. a mi
			</label>
		</div>
		<?php echo Form::hidden('id', null, ['id' => 'id']); ?>

	</div>
	<div class="modal-footer">
		<button type="submit" class="btn btn-info">Enviar</button>
		<button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
	</div>
	<?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>