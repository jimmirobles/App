<div class="form-group">
	<?php echo Form::label('name', 'Nombre(s):'); ?>

	<?php echo Form::text('name', null, ['class'=>'form-control', 'required']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('email', 'Email:'); ?>

	<?php echo Form::email('email', null, ['class'=>'form-control', 'placeholder'=>'ejemplo@mail.com', 'required']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('password', 'Contraseña:'); ?>

	<?php echo Form::password('password', ['class'=>'form-control']); ?>

</div>
<div class="form-group">
	<?php echo Form::submit('Guardar', ['class'=>'btn btn-default']); ?>

</div>