<?php $__env->startComponent('mail::message'); ?>
# Cliente

Se ha generado un nuevo servicio de soporte. Puede hacer click en el siguiente botón para consultarlo. Folio: 

<?php $__env->startComponent('mail::button', ['url' => 'http://humanbusiness.com.mx/documentos/1']); ?>
Ver servicio
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
