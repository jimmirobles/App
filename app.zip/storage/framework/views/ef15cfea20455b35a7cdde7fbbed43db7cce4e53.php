<!DOCTYPE html>
<html lang="es">
<head>

	<?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">

	<div id="wrapper">
		<!-- Navigation -->
		<?php echo $__env->make('includes.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<!-- Page Content -->
		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
					<h1 class="h2"><?php echo $__env->yieldContent('wrapper-title'); ?></h1>
					<?php echo $__env->yieldContent('title-buttons'); ?>
				</div>
				<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->yieldContent('content'); ?>
				<hr>
			</div>
			<!-- /.container-fluid -->
		</div>
		<!-- /#page-wrapper -->
		<footer class="sticky-footer">
		  <div class="container">
			<div class="text-center">
			  <small>Copyright © Human Business 2018</small>
			</div>
		  </div>
		</footer>    
		<!-- Scroll to Top Button-->
		<a class="scroll-to-top rounded" href="#page-top">
		  <i class="fa fa-angle-up"></i>
		</a>
	</div>
	<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo e(csrf_field()); ?></form>
	<!-- /#wrapper -->
<?php echo $__env->make('includes.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('custom_scripts'); ?>
</body>
</html>
