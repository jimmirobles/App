<div class="form-group">
	<?php echo Form::label('razon_social', 'Nombre: *'); ?>

	<?php echo Form::text('razon_social', null, ['class'=>'form-control', 'placeholder'=>'Inserta la razon social', 'required']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('rfc', 'R.F.C.: *'); ?>

	<?php echo Form::text('rfc', null, ['class'=>'form-control', 'placeholder'=>'XAXX010101000', 'required']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('direccion', 'Domicilio:'); ?>

	<?php echo Form::text('direccion', null, ['class'=>'form-control', 'placeholder'=>'Inserta el domicilio de la empresa']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('correo', 'Correo electronico: *'); ?>

	<?php echo Form::email('correo', null, ['class'=>'form-control', 'placeholder'=>'alguien@mail.com', 'required']); ?>

</div>
<div class="form-group">
	<?php echo Form::submit('Guardar', ['class'=>'btn btn-default']); ?>

</div>