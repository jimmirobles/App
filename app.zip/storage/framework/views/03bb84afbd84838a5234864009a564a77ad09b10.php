<?php $__env->startSection('title', 'Servicios'); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Listado de Servicios</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
    	<div class="col-lg-12">
    		<div class="panel panel-default">
    			<div class="panel-heading">
    				Servicios
    				<button class="btn btn-default btn-xs pull-right">Nuevo</button>
    			</div>
    			<div class="panel-body">
    				<div class="table-responsive">
    					<table class="table table-striped table-bordered table-hover">
    						<thead>
    							<tr>
    								<th>#</th>
    								<th>Nombre</th>
    							</tr>
    						</thead>
    						<tbody>
    							<tr>
    								<td></td>
    								<td></td>
    							</tr>
    						</tbody>
    					</table>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>