<?php $__env->startSection('page-title', 'Editar asesor'); ?>

<?php $__env->startSection('title', 'Editar'); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-12">
			<?php echo Form::open(['route'=>['asesores.update', $asesor->id], 'method'=>'PUT']); ?>

				<div class="form-group">
					<?php echo Form::label('nombre', 'Nombre:'); ?>

					<?php echo Form::text('nombre', $asesor->nombre, ['class'=>'form-control', 'required']); ?>

				</div>
				<div class="form-group">
					<?php echo Form::label('email', 'Correo electronico:'); ?>

					<?php echo Form::text('email', $asesor->email, ['class'=>'form-control', 'required']); ?>

				</div>
				<div class="form-group">
					<?php echo Form::submit('Actualizar', ['class'=>'btn btn-default']); ?>

				</div>
			<?php echo Form::close(); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>