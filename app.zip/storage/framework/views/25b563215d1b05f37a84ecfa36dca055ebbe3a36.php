<?php $__env->startSection('page-title', 'Servicios'); ?>

<?php $__env->startSection('title', 'Listado de asesores'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
    	<div class="col-lg-12">
    		<div class="panel panel-default">
    			<div class="panel-heading">
    				Asesores
    				<a href="<?php echo e(route('asesores.create')); ?>" class="btn btn-default btn-xs pull-right">
                        <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Nuevo
                    </a>
    			</div>
    			<div class="panel-body">
    				<div class="table-responsive">
    					<table class="table table-striped table-bordered table-hover">
    						<thead>
    							<tr>
    								<th>#</th>
    								<th>Nombre</th>
                                    <th>Correo</th>
                                    <th class="col-lg-2">Acción</th>
    							</tr>
    						</thead>
    						<tbody>
                                <?php $__currentLoopData = $asesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($asesor->id); ?></td>
                                    <td><?php echo e($asesor->nombre); ?></td>
                                    <td><?php echo e($asesor->email); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('asesores.edit', $asesor->id)); ?>" class="btn btn-default btn-xs">
                                            <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Editar
                                        </a>
                                        <a href="<?php echo e(route('asesores.destroy', $asesor->id)); ?>" onclick="return confirm('¿Deseas eliminarlo?')" class="btn btn-danger btn-xs">
                                            <span class="glyphicon glyphicon-trash" aria-hidden="true"></span> Borrar
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    						</tbody>
    					</table>
    				</div>
                    <?php echo e($asesores->links()); ?>

    			</div>
    		</div>
    	</div>
    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>