<!DOCTYPE html>
<html lang="es">
<head>

    <?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>
<body>

    <div id="wrapper">
        <!-- Navigation -->
        <?php echo $__env->make('includes.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header"><?php echo $__env->yieldContent('title'); ?></h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

<?php echo $__env->make('includes.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
    $('#flash-overlay-modal').modal();
</script>
<?php echo $__env->yieldContent('custom_scripts'); ?>
</body>
</html>
