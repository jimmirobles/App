<?php $__env->startSection('page-title', 'Comentarios'); ?>

<?php $__env->startSection('wrapper-title'); ?>
	<i class="fa fa-comments-o"></i> Comentarios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="table-responsive">
		<table class="table table-bordered table-sm">
			<thead class="thead-light">
				<tr>
					<th>Fecha</th>
					<th>Folio</th>
					<th>Cliente</th>
					<th class="text-center"><i class="fa fa-cog fa-lg"></i></th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<th scope="row"><?php echo e($comentario->created_at); ?></th>
					<td><?php echo e($comentario->id_documento); ?></td>
					<td><?php echo e($comentario->nombreCliente); ?></td>
					<td>
						<div class="btn-group" role="group">
							<a role="button" href="" class="btn btn-info btn-sm"><i class="fa fa-eye"></i> Ver</a>
							<a role="button" href="" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
						</div>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	<?php echo e($comentarios->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>