<?php $__env->startSection('page-title', 'Nuevo contacto'); ?>

<?php $__env->startSection('wrapper-title'); ?>
	<i class="fa fa-pencil"></i> Crear contacto
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-12">

			<?php echo $__env->make('errors.form-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
			<?php echo Form::open(['route'=>'contactos.store', 'method'=>'POST']); ?>

				<?php echo $__env->make('forms.contactos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo Form::close(); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_scripts'); ?>
<script>
	$(function () {
		$('.select2').select2({
			theme: "bootstrap"
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>