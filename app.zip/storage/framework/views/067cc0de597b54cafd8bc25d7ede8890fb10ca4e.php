<nav class="navbar navbar-default" role="navigation">
  <div class="container-fluid">
	<div class="navbar-header">
	  <a class="navbar-brand" href="#">
		<img alt="Brand" src="<?php echo e(asset('img/logo-512x512.png')); ?>" width="25px">
	  </a>
	</div>
	<ul class="nav navbar-top-links navbar-right">
		<li class="dropdown">
			<a class="dropdown-toggle" data-toggle="dropdown" href="#">
				<i class="fa fa-user fa-fw"></i> <?php echo e(auth()->user()->name); ?> <i class="fa fa-caret-down"></i>
			</a>
			<ul class="dropdown-menu dropdown-user">
				<li><a href="#"><i class="fa fa-user fa-fw"></i> Perfil</a>
				</li>
				<li><a href="<?php echo e(route('clear-all')); ?>"><i class="fa fa-gear fa-fw"></i> Limpiar PDF's <span class="badge"><?php echo e(count($storageFiles)); ?></span></a>
				</li>
				<li class="divider"></li>
				<li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fa fa-sign-out fa-fw"></i> Salir</a>
				</li>
			</ul>
			<!-- /.dropdown-user -->
		</li>  
	</ul>
  </div>
</nav>