<!-- Modal -->
<div class="modal fade" id="<?php echo $__env->yieldContent('modal-id'); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="myModalLabel"><?php echo $__env->yieldContent('modal-title'); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<?php echo $__env->yieldContent('modal-content'); ?>
		</div>
	</div>
</div>