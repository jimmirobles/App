<?php $__env->startSection('page-title', 'Empresas'); ?>

<?php $__env->startSection('title', 'Listado de empresas'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
    	<div class="col-lg-12">
    		<div class="panel panel-default">
    			<div class="panel-heading">
    				Empresas
    				<a href="/empresas/create" class="btn btn-info btn-xs pull-right">Nuevo</a>
    			</div>
    			<div class="panel-body">
    				<div class="table-responsive">
    					<table class="table table-striped table-bordered table-hover">
    						<thead>
    							<tr>
    								<th>#</th>
    								<th>Nombre</th>
                                    <th>RFC</th>
                                    <th>Acción</th>
    							</tr>
    						</thead>
    						<tbody>
                                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($empresa->id); ?></td>
                                    <td><?php echo e($empresa->razon_social); ?></td>
                                    <td><?php echo e($empresa->rfc); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('empresas.edit', $empresa->id)); ?>" class="btn btn-default btn-xs">Editar</a>
                                        <a href="<?php echo e(route('empresas.destroy', $empresa->id)); ?>" onclick="return confirm('¿Deseas eliminarlo?')" class="btn btn-danger btn-xs">Eliminar</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    						</tbody>
    					</table>
    				</div>
                    <?php echo e($empresas->links()); ?>

    			</div>
    		</div>
    	</div>
    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>