<?php $__env->startSection('modal-id', 'myModal'); ?>
<?php $__env->startSection('modal-title', 'Listado de archivos...'); ?>

<?php $__env->startSection('modal-body'); ?>
	<div class="modal-body">
		<ul>
		<?php $__currentLoopData = $storageFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($file); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>