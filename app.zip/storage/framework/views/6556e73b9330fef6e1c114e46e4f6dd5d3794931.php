<div class="form-group">
	<?php echo Form::label('id_cliente', 'Cliente:*'); ?>

	<?php echo Form::select('id_cliente', $clientes->all(), null, ['class'=>'form-control select2', 'placeholder'=>'Selecciona algo...', 'required']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('nombre', 'Nombre: *'); ?>

	<?php echo Form::text('nombre', null, ['class'=>'form-control', 'required']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('email', 'Correo electrónico: *'); ?>

	<?php echo Form::text('email', null, ['class'=>'form-control', 'required']); ?>

</div>
<div class="form-group">
	<?php echo Form::submit('Guardar', ['class'=>'btn btn-primary']); ?>

	<a class="btn btn-danger" href="<?php echo e(URL::previous()); ?>">Cancelar</a>
</div>