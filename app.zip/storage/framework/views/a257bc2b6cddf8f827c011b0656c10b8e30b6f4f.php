<?php $__env->startComponent('mail::message'); ?>
# Estimado cliente

Se ha generado un nuevo servicio de soporte con folio: <?php echo e($folio); ?>. Lo puede localizar como un archivo adjunto al presente correo electrónico, de igual forma lo puede consultar vía web haciendo click en el siguiente botón: 

<?php $__env->startComponent('mail::button', ['url' => url('documentos/'. $id) ]); ?>
Ver servicio
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
