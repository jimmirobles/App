<div class="form-group">
	<?php echo Form::label('razon_social', 'Nombre: *'); ?>

	<?php echo Form::text('razon_social', null, ['class'=>'form-control', 'required']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('rfc', 'R.F.C.: *'); ?>

	<?php echo Form::text('rfc', null, ['class'=>'form-control', 'required']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('email', 'Email Supervisor: *'); ?>

	<?php echo Form::email('email', null, ['class'=>'form-control', 'required']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('direccion', 'Denominacion comercial:'); ?>

	<?php echo Form::text('direccion', null, ['class'=>'form-control']); ?>

</div>
<div class="form-group">
	<?php echo Form::submit('Guardar', ['class'=>'btn btn-primary']); ?>

	<a class="btn btn-danger" href="<?php echo e(URL::previous()); ?>">Cancelar</a>
</div>