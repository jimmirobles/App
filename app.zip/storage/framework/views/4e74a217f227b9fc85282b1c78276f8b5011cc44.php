<?php $__env->startSection('page-title', 'Empresas'); ?>

<?php $__env->startSection('wrapper-title'); ?>
	<i class="fa fa-user-circle-o"></i> Clientes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-buttons'); ?>
	<div class="pull-right">
		<div class="btn-group btn-group-sm" role="group" aria-label="Botones de acciones de tabla">
			<a role="button" href="<?php echo e(route('clientes.create')); ?>" class="btn btn-sm btn-outline-primary"><i class="fa fa-pencil fa-fw"></i> Nuevo</a>
			<div class="btn-group btn-group-sm" role="group">
			<button id="btnGroupDrop1" type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
			<div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
				<a class="dropdown-item" href="<?php echo e(route('excel.exportar', 'clientes')); ?>">Descargar .XLS</a>
			</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="table-responsive">
		<table class="table table-bordered table-striped" id="clients-table">
			<thead>
				<tr>
					<th>RFC</th>
					<th>Nombre</th>
					<th class="text-center"><i class="fa fa-cog fa-lg"></i></th>
				</tr>
			</thead>
			<tbody>
				
			</tbody>
		</table>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_scripts'); ?>
<script>
	$(document).ready(function(){
		$('#clients-table').DataTable({
			"language": {
				"url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Spanish.json"
			},
			"order": [[ 0, "asc" ]],
			"columnDefs": [
				{ "orderable": false, "targets": 2 }
			],
			"processing": true,
			"serverSide": true,
			"ajax": "<?php echo e(route('api.clientes')); ?>",
			"columns":[
				{data: 'rfc'},
				{data: 'razon_social'},
				{data: 'action'},
			]
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>