<?php $__env->startSection('title', 'Asesores'); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Listado de Asesores</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>