<?php

namespace CRM\Http\Controllers;

use Illuminate\Http\Request;
use CRM\Servicio;
use CRM\Cliente;
use Excel;

class ExcelController extends Controller
{

    /**
     *
     */
    public function exportar($tipo) {

        switch ($tipo){
            case 'clientes':
                $data = Cliente::select('id', 'razon_social', 'rfc', 'direccion', 'email')
                    ->get();
            case 'servicios':
                $data = Servicio::select('id', 'nombre')
                    ->get();
        }

        Excel::create('Todos los '.$tipo, function($excel) use($data) {
            $excel->sheet('Sheetname', function($sheet) use($data) {

                $sheet->fromArray($data);

            });
        })->export('xlsx');
    }
}
