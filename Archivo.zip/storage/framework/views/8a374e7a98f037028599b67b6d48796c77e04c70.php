<?php $__env->startSection('page-title', 'Crear documento'); ?>

<?php $__env->startSection('title', 'Crear'); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-12">
			<?php if(count($errors) > 0): ?>
				<div class="alert alert-danger alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
			<?php endif; ?>
			<?php echo Form::open(['route'=>'documentos.store', 'method'=>'POST']); ?>

				<section class="row">
					<div class="col-lg-2 form-group">
						<?php echo Form::label('folio', 'Folio:'); ?>

						<?php echo Form::text('folio', $next_folio+1, ['class'=>'form-control date', 'readonly']); ?>

					</div>
					<div class="col-lg-4 form-group">
						<?php echo Form::label('fecha', 'Fecha:'); ?>

						<?php echo Form::text('fecha', null, ['class'=>'form-control date', 'id' => 'datepicker', 'placeholder'=>'dd/mm/aaaa', 'required']); ?>

					</div>
					<div class="col-lg-3 form-group">
						<?php echo Form::label('hInicial', 'Hora inicial:'); ?>

						<?php echo Form::text('hInicial', null, ['class' => 'form-control timepicker', 'placeholder' => 'Hora de inicio', 'required']); ?>

					</div>
					<div class="col-lg-3 form-group">
						<?php echo Form::label('hFinal', 'Hora final:'); ?>

						<?php echo Form::text('hFinal', null, ['class' => 'form-control timepicker', 'placeholder' => 'Hora de finalizacion', 'required']); ?>

					</div>
				</section>
				<section class="row">
					<div class="col-lg-12 form-group">
						<?php echo Form::label('empresa', 'Empresa:'); ?>

						<?php echo Form::select('id_empresa', $empresas->all(), null, ['class'=>'form-control select2', 'placeholder'=>'Selecciona algo...', 'required']); ?>

					</div>
				</section>
				<section class="row">
					<div class="col-lg-6 form-group">
						<?php echo Form::label('sistema', 'Servicio:'); ?>

						<?php echo Form::select('id_servicio', $servicios->all(), null, ['class'=>'form-control select2', 'placeholder'=>'Selecciona algo...', 'required']); ?>

					</div>
					<div class="col-lg-6 form-group">
						<?php echo Form::label('asesor', 'Asesor:'); ?>

						<?php echo Form::select('id_asesor', $asesores->all(), null, ['class'=>'form-control select2', 'placeholder'=>'Selecciona algo...', 'required']); ?>

					</div>
				</section>
				<section class="row">
					<div class="col-lg-12 form-group">
						<?php echo Form::label('error', 'Error reportado:'); ?>

						<?php echo Form::textarea('error', null, ['class' => 'form-control', 'rows' => '3']); ?>

					</div>
					<div class="col-lg-12 form-group">
						<?php echo Form::label('solucion', 'Actividad realizada:'); ?>

						<?php echo Form::textarea('solucion', null, ['class' => 'form-control', 'rows' => '3']); ?>

					</div>
					<div class="col-lg-12 form-group">
						<?php echo Form::label('comentarios', 'Comentrios adicionales:'); ?>

						<?php echo Form::textarea('comentarios', null, ['class' => 'form-control', 'rows' => '3']); ?>

					</div>
				</section>
				<div class="form-group">
					<?php echo Form::submit('Guardar', ['class'=>'btn btn-default']); ?>

				</div>
			<?php echo Form::close(); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_scripts'); ?>
<script>
	$(function () {
        $('#datepicker').datetimepicker({
        	locale: 'es',
        	format: 'YYYY/MM/DD',
        	daysOfWeekDisabled: [0],
        	showTodayButton: true,
        	showClose: true
        });
        $('.timepicker').datetimepicker({
        	locale: 'es',
        	format: 'hh:mm A',
        	showTodayButton: true,
        	showClose: true
        });
        $('.select2').select2({
        	theme: "bootstrap"
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>