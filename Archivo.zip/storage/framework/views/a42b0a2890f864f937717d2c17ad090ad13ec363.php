<div class="modal fade" id="modal_servicio" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Nuevo servicio</h4>
			</div>
			<?php echo Form::open(['id' => 'form_servicio']); ?>

			<div class="modal-body">
				<div class="form-group">
					<?php echo Form::label('serv_nombre', 'Nombre:'); ?>

					<?php echo Form::text('serv_nombre', null, ['class'=>'form-control', 'placeholder'=>'Inserta el nombre del servicio', 'required']); ?>

				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
				<?php echo link_to('#', 'Guardar', ['id' => 'guardar_servicio', 'class' => 'btn btn-primary']); ?>

			</div>
			<?php echo Form::close(); ?>

		</div>
	</div>
</div>