<?php $__env->startSection('page-title', 'Servicios'); ?>

<?php $__env->startSection('title', 'Listado de servicios'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
    	<div class="col-lg-12">
    		<div class="panel panel-default">
    			<div class="panel-heading">
    				Servicios
    				<a href="<?php echo e(route('servicios.create')); ?>" class="btn btn-default btn-xs pull-right">
                        <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> Nuevo
                    </a>
    			</div>
    			<div class="panel-body">
    				<div class="table-responsive">
    					<table class="table table-striped table-bordered table-hover">
    						<thead>
    							<tr>
    								<th>#</th>
    								<th>Nombre</th>
                                    <th class="col-lg-2">Acción</th>
    							</tr>
    						</thead>
    						<tbody>
                                <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($servicio->id); ?></td>
                                    <td><?php echo e($servicio->nombre); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('servicios.edit', $servicio->id)); ?>" class="btn btn-default btn-xs">
                                            <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Editar
                                        </a>
                                        <a href="<?php echo e(route('servicios.destroy', $servicio->id)); ?>" onclick="return confirm('¿Deseas eliminarlo?')" class="btn btn-danger btn-xs"> 
                                            <span class="glyphicon glyphicon-trash" aria-hidden="true"></span> Borrar
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    						</tbody>
    					</table>
    				</div>
                    <?php echo e($servicios->links()); ?>

    			</div>
    		</div>
    	</div>
    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>