<?php $__env->startSection('page-title', 'Editar empresa'); ?>

<?php $__env->startSection('title', 'Editar'); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-12">
			<?php echo Form::model($empresa, ['route'=>['clientes.update', $empresa->id], 'method'=>'PUT']); ?>

				<?php echo $__env->make('forms.empresas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo Form::close(); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>