<div class="form-group">
	<?php echo Form::label('nombre', 'Nombre:'); ?>

	<?php echo Form::text('nombre', null, ['class'=>'form-control', 'placeholder'=>'Inserta el nombre del servicio', 'required']); ?>

</div>
<div class="form-group">
	<?php echo Form::submit('Guardar', ['class'=>'btn btn-default']); ?>

</div>