<?php $__env->startSection('page-title', 'Crear documento'); ?>

<?php $__env->startSection('title', 'Crear'); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-12">

			<?php echo $__env->make('errors.form-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
			<?php echo Form::open(['route'=>'documentos.store', 'method'=>'POST']); ?>

				<section class="row">
					<div class="col-lg-2 form-group">
						<?php echo Form::label('folio', 'Folio:'); ?>

						<?php echo Form::text('folio', $next_folio+1, ['class'=>'form-control date', 'readonly']); ?>

					</div>
					<div class="col-lg-2 form-group">
						<?php echo Form::label('fecha', 'Fecha:'); ?>

						<?php echo Form::text('fecha', null, ['class'=>'form-control date', 'id' => 'datepicker', 'placeholder'=>'dd/mm/aaaa', 'required']); ?>

					</div>
					<div class="col-lg-2 form-group">
						<?php echo Form::label('hInicial', 'Hora inicial:'); ?>

						<?php echo Form::text('hInicial', null, ['class' => 'form-control timepicker', 'required']); ?>

					</div>
					<div class="col-lg-2 form-group">
						<?php echo Form::label('hFinal', 'Hora final:'); ?>

						<?php echo Form::text('hFinal', null, ['class' => 'form-control timepicker', 'required']); ?>

					</div>
					<div class="col-lg-4 form-group">
						<?php echo Form::label('tipo', 'Tipo:'); ?>

						<?php echo Form::select('tipo', ['1' => 'En sitio', '2' => 'Remoto'], null, ['class'=>'form-control select2', 'placeholder'=>'Selecciona algo...', 'required']); ?>

					</div>
				</section>
				<section class="row">
					<div class="col-lg-12 form-group">
						<?php echo Form::label('id_cliente', 'Cliente:'); ?>

						<?php echo Form::select('id_cliente', $empresas->all(), null, ['class'=>'form-control select2', 'placeholder'=>'Selecciona algo...', 'required']); ?>

					</div>
				</section>
				<section class="row">
					<div class="col-lg-6 form-group">
						<?php echo Form::label('contacto_nombre', 'Contacto:'); ?>

						<?php echo Form::text('contacto_nombre', null, ['class' => 'form-control', 'required']); ?>

					</div>
					<div class="col-lg-6 form-group">
						<?php echo Form::label('contacto_email', 'Email:'); ?>

						<?php echo Form::email('contacto_email', null, ['class' => 'form-control', 'required']); ?>

					</div>
				</section>
				<section class="row">
					<div class="col-lg-6 form-group">
						<?php echo Form::label('id_servicio', 'Servicio:'); ?>

						<?php echo Form::select('id_servicio', $servicios->all(), null, ['class'=>'form-control select2 col-lg-4', 'placeholder'=>'Selecciona algo...', 'required']); ?>

					</div>
					<div class="col-lg-6 form-group">
						<?php echo Form::label('id_asesor', 'Asesor:'); ?>

						<?php echo Form::select('id_asesor', $asesores->all(), null, ['class'=>'form-control select2', 'placeholder'=>'Selecciona algo...', 'required']); ?>

					</div>
				</section>
				<section class="row">
					<div class="col-lg-12 form-group">
						<?php echo Form::label('error', 'Error reportado:'); ?>

						<?php echo Form::textarea('error', null, ['class' => 'form-control', 'rows' => '3']); ?>

					</div>
					<div class="col-lg-12 form-group">
						<?php echo Form::label('solucion', 'Actividad realizada:'); ?>

						<?php echo Form::textarea('solucion', null, ['class' => 'form-control', 'rows' => '3']); ?>

					</div>
					<div class="col-lg-12 form-group">
						<?php echo Form::label('comentarios', 'Comentrios adicionales:'); ?>

						<?php echo Form::textarea('comentarios', null, ['class' => 'form-control', 'rows' => '3']); ?>

					</div>
				</section>
				<div class="form-group">
					<?php echo Form::submit('Guardar', ['class'=>'btn btn-default']); ?>

				</div>
			<?php echo Form::close(); ?>

		</div>
	</div>

	<?php echo $__env->make('modal.servicio', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_scripts'); ?>
<script>
	$(function () {
        $('#datepicker').datetimepicker({
        	locale: 'es',
        	format: 'YYYY/MM/DD',
        	daysOfWeekDisabled: [0],
        	showTodayButton: true,
        	showClose: true
        });
        $('.timepicker').datetimepicker({
        	locale: 'es',
        	format: 'hh:mm A',
        	showTodayButton: true,
        	showClose: true
        });
        $('.select2').select2({
        	theme: "bootstrap"
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>