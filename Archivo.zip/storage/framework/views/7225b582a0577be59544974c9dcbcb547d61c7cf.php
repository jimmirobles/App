<?php $__env->startSection('page-title', 'Crear usuario'); ?>

<?php $__env->startSection('title', 'Nuevo usuario'); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-12">

			<?php echo $__env->make('errors.form-error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<?php echo Form::open(['route'=>'usuarios.store', 'method'=>'POST']); ?>

				<?php echo $__env->make('forms.usuarios', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo Form::close(); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>