<?php $__env->startComponent('mail::message'); ?>
# Cliente

Se ha generado un nuevo servicio de soporte. Folio: <?php echo e($folio); ?>, puede hacer click en el siguiente botón para consultarlo. 

<?php $__env->startComponent('mail::button', ['url' => url('documentos/'. $folio) ]); ?>
Ver servicio
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
