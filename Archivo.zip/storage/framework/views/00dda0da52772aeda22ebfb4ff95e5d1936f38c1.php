    <!-- jQuery -->
    <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('plugins/moment.min.js')); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    
    <script src="<?php echo e(asset('plugins/datetimepicker/js/datetimepicker.min.js')); ?>"></script>
    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo e(asset('plugins/metisMenu/metisMenu.min.js')); ?>"></script>
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo e(asset('js/sb-admin-2.js')); ?>"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>