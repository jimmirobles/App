<?php $__env->startSection('page-title', 'Crear asesor'); ?>

<?php $__env->startSection('title', 'Crear'); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-12">
			<?php if(count($errors) > 0): ?>
				<div class="alert alert-danger alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
			<?php endif; ?>
			<?php echo Form::open(['route'=>'asesores.store', 'method'=>'POST']); ?>

				<div class="form-group">
					<?php echo Form::label('nombre', 'Nombre:'); ?>

					<?php echo Form::text('nombre', null, ['class'=>'form-control', 'placeholder'=>'Inserta el nombre del asesor', 'required']); ?>

				</div>
				<div class="form-group">
					<?php echo Form::label('email', 'Email:'); ?>

					<?php echo Form::email('email', null, ['class'=>'form-control', 'placeholder'=>'ejemplo@mail.com', 'required']); ?>

				</div>
				<div class="form-group">
					<?php echo Form::submit('Guardar', ['class'=>'btn btn-default']); ?>

				</div>
			<?php echo Form::close(); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>